<?php

  $continents = [ "Africa", "Asia","Europe","North America", "South America"  ];

  $countries = [
    "CA"=>"Canada","FR"=>"France","IT"=>"Italy","DE"=>"Germany","GH"=>"Ghana","GR"=>"Greece","ES"=>"Spain","US"=>"United States","GB"=>"United Kingdom"
  ];  

  $posts = [
    ["postId"=>1, "userId"=>2, "userName"=>"Leonie Kohler", "date"=>"2/8/2017","thumb"=>"8710320515.jpg","title"=>"Ekklisia Agii Isidori Church","reviewsNum"=>15,"reviewsRating"=>3,"excerpt"=>"At the end of the hot climb up to the top Lycabettus Hill you are greeted with the oasis that is the Ekklisia Agii Isidori church."],
    ["postId"=>3, "userId"=>5, "userName"=>"Frantisek  Wichterlova", "date"=>"9/9/2017","thumb"=>"8710247776.jpg","title"=>"Santorini Sunset","reviewsNum"=>38,"reviewsRating"=>5,"excerpt"=>"Every evening as the sun sets in Fira, it seems that everyone who is not drinking or eating is rushing with their camera to the most picturesque locations in order to capture that famous Aegean sunset."],
    ["postId"=>9, "userId"=>13, "userName"=>"Edward Francis", "date"=>"10/19/2019","thumb"=>"8710289254.jpg","title"=>"Looking towards Fira","reviewsNum"=>3,"reviewsRating"=>2,"excerpt"=>"The steamer Mongolia, belonging to the Peninsular and Oriental Company, built of iron, of two thousand eight hundred tons burden, and five hundred horse-power, was due at eleven o'clock a.m. on Wednesday, the 9th of October, at Suez."]
  ];




  
?>